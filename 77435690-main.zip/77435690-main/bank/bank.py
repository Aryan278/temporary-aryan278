greeting = input("Greeting: ").lower().strip()

def identify():
    if "hello" in greeting:
        print("$0")
    elif greeting.startswith("h"):
        print("$20")
    else:
        print("$100")

identify()
