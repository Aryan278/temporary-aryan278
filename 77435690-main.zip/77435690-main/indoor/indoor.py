def lowercase():
    caps_input = input("please enter the word you wish to change into lowercase: ").swapcase()
    print(caps_input)

lowercase()
