def einstein_formula():
    mass = int(input("mass (in kg): "))
    c = 300000000

    Energy = mass * pow(c , 2)

    print(Energy)

einstein_formula()
