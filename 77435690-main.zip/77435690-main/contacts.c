#include <stdio.h>
#include <cs50.h>

void print_row(int length, int spaces);

int main(void)
{
    int z = get_int("how many X's do you want?\n");
    for (int i = 0; i < z; i++){
        print_row(i + 1, z - (i + 1));
    }
}

void print_row(int length, int spaces)
{
    for (int i = 0; i < spaces; i++)
    {
        printf(" ");
    }
    for (int i = 0; i < length; i++)
    {
        printf("X");
    }
    printf("\n");
}
