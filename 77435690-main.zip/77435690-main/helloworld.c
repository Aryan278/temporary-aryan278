#include <stdio.h>
#include <cs50.h>

int main(void)
{
     string answer = get_string("whats your name?\n");
     printf("your name is %s\n", answer);
}
