def main():
    current_time = input("what time is it? ")
    x = convert(current_time)
    if 7 <= x <= 8:
        print("breakfast time")
    elif 12 <= x <= 13:
        print("lunch time")
    elif 18 <= x <= 19:
        print("dinner time")
    else:
        print("leisure time")


def convert(time):
    hours, minutes = time.split(":")
    x = int(minutes)/60

    return float(hours) + float(x)

if __name__ == "__main__":
    main()
