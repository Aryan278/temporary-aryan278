x, y, z = input("Expression: ").split(" ")

def operations(p):   #math function for +,-,*,/
    if p == "+":
        print(round(float(x)+float(z), 1))
    elif p == "-":
        print(round(float(x)-float(z), 1))
    elif p == "*":
        print(round(float(x)*float(z), 1))
    else:
        print(round(float(x)/float(z), 1))

operations(y)
