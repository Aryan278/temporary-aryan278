def main():
    camelCase = input("camelCase: ")
    print(f"snake_case: {convert(camelCase)}")


def convert(x):
    python_case = ""  

    for c in x:
        if c.isupper():
            python_case += f"_{c.lower()}"
        else:
            python_case += c

    return python_case


main()
