def main():

    while True:

        try:

            fraction = input("Fraction: ")
            x,y = fraction.split("/")
            if fraction_to_percentage(x,y) > 1:
                print(f"{fraction_to_percentage(x,y)}%")
            elif fraction_to_percentage(x,y) <= 1:
                print("E")

        except (ValueError, ZeroDivisionError):
            continue

        else:
            break

def fraction_to_percentage(a,b):
    return round(int(a)/int(b) * 100)

main()
