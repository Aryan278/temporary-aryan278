def convert():
    converted_input = user_input.replace(":(" , "🙁").replace(":)" , "🙂")
    return converted_input

def main():
    global user_input
    user_input = input("enter a phrase: ")
    final = convert()
    print(final)

main()
