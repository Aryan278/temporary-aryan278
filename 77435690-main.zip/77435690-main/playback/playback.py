def replacing_whitespaces():
    user_input = input("please provide a phrase: ").replace(" " , "...")
    print(user_input)

replacing_whitespaces()

