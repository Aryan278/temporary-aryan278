def main():
    grocery = {}

    try:
        while True:
                item = input().strip().lower()

                try:
                        grocery[item] += 1
                except KeyError:
                        grocery[item] = 1
    except EOFError:
         pass

    sorted_items = sorted(grocery.items())

    for item, count in sorted_items:
          print(f"{count} {item.upper()}")

main()
