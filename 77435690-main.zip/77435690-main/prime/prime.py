#prime number checker 

import math

user_input = int(input("enter number: "))

sqrtnum = int(math.sqrt(user_input))

oddnum = []
for i in range(3,sqrtnum):
    if i % 2 != 0:
        oddnum.append(i)

if user_input == 2:
    print("The number is prime")

if user_input % 2 == 0:
        print("The number is not a prime")

else:
    is_prime = True
    for x in oddnum:
        if user_input % x == 0:
            is_prime = False
            break

    if is_prime == False:
        print("The number is not a prime")
    else:
        print("The number is prime")
