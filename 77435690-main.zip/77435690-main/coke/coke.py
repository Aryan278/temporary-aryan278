def main():
    amountdue = 50

    while amountdue > 0:
        InsertCoin = int(input("Insert Coin: "))
        print(f"Amount Due: {amountdue}")

        if InsertCoin == 5:
            amountdue = amountdue - 5
            print(f"Amount Due: {amountdue}")

        elif InsertCoin == 10:
            amountdue = amountdue - 10
            print(f"Amount Due: {amountdue}")

        elif InsertCoin == 25:
            amountdue = amountdue - 25
            print(f"Amount Due: {amountdue}")

    if amountdue <= 0:
        print(f"Change Owed: {0 - amountdue}")


main()
