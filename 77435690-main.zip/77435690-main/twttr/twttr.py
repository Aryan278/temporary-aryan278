def main():
    Iput = input("Input: ")

    Vowels = ["a", "e", "i", "o", "u", "A", "E", "I", "O", "U"]

    print(f"Output: {''.join(vowel for vowel in Iput if vowel not in Vowels)}")

main()
