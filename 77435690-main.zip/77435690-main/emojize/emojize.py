import requests
import emoji

def main():
    #takes user input
    user_input = input("Input: ")

    #converting user input into emoji by calling api and storing in variable
    converted_emoji = emoji.emojize(f'Output: {user_input}', language='alias')

    #printing the converted emoji
    print(converted_emoji)

main()
