import inflect

try:
#asking for user input and storing names in a list
    names = input("Name)
except EOFError:
    break
